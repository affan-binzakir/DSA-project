import java.io.*;
import java.sql.Time;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;
import java.util.regex.Pattern;

class User implements Serializable {
    private String username;
    private String email;
    private String fullName;
    private String location;
    private List<String> interests;
    private String password;
    private String dob;
    private UUID userID;
    private List<UUID> friends;
    private List<UUID> friendRequests;
    private Queue<String> posts;
    private Map<UUID, Integer> suggestionHistory;

    public User(String username, String email, String fullName, String location, List<String> interests, String password, String dob) {
        this.username = username;
        this.email = email;
        this.fullName = fullName;
        this.location = location;
        this.interests = interests;
        this.password = password;
        this.dob = dob;
        this.userID = UUID.randomUUID();
        this.friends = new ArrayList<>();
        this.friendRequests = new ArrayList<>();
        this.posts = new LinkedList<>();
        this.suggestionHistory = new HashMap<>();
    }

    public String getUsername() {
        return username;
    }

    public String getEmail() {
        return email;
    }

    public String getFullName() {
        return fullName;
    }

    public String getLocation() {
        return location;
    }

    public List<String> getInterests() {
        return interests;
    }

    public String getPassword() {
        return password;
    }

    public UUID getUserID() {
        return userID;
    }

    public List<UUID> getFriends() {
        return friends;
    }

    public List<UUID> getFriendRequests() {
        return friendRequests;
    }

    public Queue<String> getPosts() {
        return posts;
    }

    public void addPost(String post) {
        posts.add(post);
    }
    public Map<UUID, Integer> getSuggestionHistory() {
        return suggestionHistory;
    }

    public void addFriendRequest(UUID userID) {
        friendRequests.add(userID);
    }

    public void acceptFriendRequest(UUID userID) {
        if (friendRequests.contains(userID)) {
            friends.add(userID);
            friendRequests.remove(userID);
        }
    }

    // HELPER FUNCTIONS

    public static boolean isValidEmail(String email) {
        String emailRegex = "^[a-zA-Z0-9_+&-]+(?:\\.[a-zA-Z0-9_+&-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }

    public static boolean isValidDOB(String dob) {
        String dobRegex = "^(0[1-9]|[12][0-9]|3[01])/(0[1-9]|1[0-2])/\\d{4}$";
        Pattern pattern = Pattern.compile(dobRegex);
        if (!pattern.matcher(dob).matches()) {
            return false;
        }

        String[] parts = dob.split("/");
        int day = Integer.parseInt(parts[0]);
        int month = Integer.parseInt(parts[1]);
        int year = Integer.parseInt(parts[2]);

        // Check day and month validity
        if (month < 1 || month > 12 || day < 1 || day > 31) {
            return false;
        }

        // Check days for months with less than 31 days
        if ((month == 4 || month == 6 || month == 9 || month == 11) && day > 30) {
            return false;
        }

        // Check February for leap year
        if (month == 2) {
            boolean isLeapYear = (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
            if ((isLeapYear && day > 29) || (!isLeapYear && day > 28)) {
                return false;
            }
        }

        return true;
    }

    public static boolean isAgeAllowed(String dob) {
        try {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy");
            LocalDate birthDate = LocalDate.parse(dob, formatter);
            LocalDate currentDate = LocalDate.now();

            // Calculate age
            int age = currentDate.getYear() - birthDate.getYear();
            if (birthDate.plusYears(age).isAfter(currentDate)) {
                age--; // Adjust if birth date hasn't occurred yet this year
            }

            return age > 12; // Allow only if age is 13 or above
        } catch (DateTimeParseException e) {
            return false; // Invalid DOB format
        }
    }
}