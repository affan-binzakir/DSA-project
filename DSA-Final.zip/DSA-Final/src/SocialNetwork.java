import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.*;

class SocialNetwork {
    private Map<UUID, User> users;
    private SocialNetworkGUI gui;

    public SocialNetwork() {
        this.users = new HashMap<>();
        loadUsers();
    }

    public void setGUI(SocialNetworkGUI gui) {
        this.gui = gui;
    }


    // TASK 1 - ADD FRIEND

    public void sendFriendRequest(User sender, String recipientUsername) {
        User recipient = getUserByUsername(recipientUsername);
        if (recipient != null && !sender.getFriends().contains(recipient.getUserID())
                && !sender.getUserID().equals(recipient.getUserID())) {
            recipient.addFriendRequest(sender.getUserID());
            saveUsers();
            if (gui != null) {
                gui.appendToFeed("Friend request sent to " + recipient.getUsername());
            }
        } else if (recipient == null) {
            if (gui != null) {
                gui.appendToFeed("User not found!");
            }
        } else if (sender.getFriends().contains(recipient.getUserID())) {
            if (gui != null) {
                gui.appendToFeed("Already friends with " + recipient.getUsername());
            }
        } else {
            if (gui != null) {
                gui.appendToFeed("Cannot send friend request to yourself!");
            }
        }
    }

    public void showFriendRequests(User user) {
        List<UUID> requests = user.getFriendRequests();
        if (requests.isEmpty()) {
            if (gui != null) {
                gui.appendToFeed("No friend requests.");
            }
        } else {
            if (gui != null) {
                gui.appendToFeed("Friend Requests:");
                for (UUID requesterID : requests) {
                    User requester = users.get(requesterID);
                    if (requester != null) {
                        gui.appendToFeed("- " + requester.getUsername());
                    }
                }
            }
        }
    }

    public void acceptFriendRequest(User user, String requesterUsername) {
        User requester = getUserByUsername(requesterUsername);
        if (requester != null && user.getFriendRequests().contains(requester.getUserID())) {
            user.acceptFriendRequest(requester.getUserID());
            requester.getFriends().add(user.getUserID());
            saveUsers();
            if (gui != null) {
                gui.appendToFeed("Friend request accepted! You are now friends with " + requester.getUsername());
            }
        } else {
            if (gui != null) {
                gui.appendToFeed("Invalid friend request.");
            }
        }
    }

    public void viewFriends(User currentUser) {
        List<UUID> friendIDs = currentUser.getFriends();

        if (friendIDs.isEmpty()) {
            if (gui != null) {
                gui.appendToFeed("You have no friends in your list.");
            }
            return;
        }

        if (gui != null) {
            gui.appendToFeed("\n=== Your Friends ===");
            for (UUID friendID : friendIDs) {
                User friend = users.get(friendID);
                if (friend != null) {
                    gui.appendToFeed("- " + friend.getUsername() + " (ID: " + friend.getUserID() + ")");
                }
            }
        }
    }

    // TASK 2 - REMOVE FRIEND

    public void removeFriend(User user, String friendUsername) {
        User friend = getUserByUsername(friendUsername);
        if (friend != null && user.getFriends().contains(friend.getUserID())) {
            user.getFriends().remove(friend.getUserID());
            friend.getFriends().remove(user.getUserID());
            saveUsers();
            if (gui != null) {
                gui.appendToFeed("You have removed " + friend.getUsername() + " from your friends list.");
            }
        } else if (friend == null) {
            if (gui != null) {
                gui.appendToFeed("User not found!");
            }
        } else {
            if (gui != null) {
                gui.appendToFeed(friendUsername + " is not in your friends list.");
            }
        }
    }




    // TASK 3 - MUTUAL FRIENDS

    public void showMutualFriends(User user1, String user2Username) {
        User user2 = getUserByUsername(user2Username);
        if (user2 == null) {
            if (gui != null) {
                gui.appendToFeed("User not found!");
            }
            return;
        }

        List<UUID> mutuals = new ArrayList<>(user1.getFriends());
        mutuals.retainAll(user2.getFriends());
        if (mutuals.isEmpty()) {
            if (gui != null) {
                gui.appendToFeed("No mutual friends with " + user2Username);
            }
        } else {
            if (gui != null) {
                gui.appendToFeed("Mutual Friends with " + user2Username + ":");
                for (UUID friendID : mutuals) {
                    User mutual = users.get(friendID);
                    if (mutual != null) {
                        gui.appendToFeed("- " + mutual.getUsername());
                    }
                }
            }
        }
    }



    // TASK 4 - SUGGEST FRIENDS

    public void suggestFriends(User currentUser) {
        Map<User, Integer> scoreMap = new HashMap<>();

        for (User user : users.values()) {
            // Skip the current user and their existing friends
            if (user.getUserID().equals(currentUser.getUserID()) || currentUser.getFriends().contains(user.getUserID())) {
                continue;
            }

            // Check if the user is a Friend of a Friend
            if (!isFriendOfFriend(currentUser, user)) {
                continue; // Skip further scoring if not a FoF
            }

            int score = 0;

            // Score based on the number of friends
            score += user.getFriends().size();

            // Score based on shared interests
            for (String interest : currentUser.getInterests()) {
                if (user.getInterests().contains(interest.trim())) {
                    score += 10;
                }
            }

            // Score based on location match
            if (user.getLocation().equalsIgnoreCase(currentUser.getLocation())) {
                score += 5;
            }

            // Calculate mutual friends
            List<UUID> mutualFriends = new ArrayList<>(currentUser.getFriends());
            mutualFriends.retainAll(user.getFriends());
            score += mutualFriends.size() * 3;

            scoreMap.put(user, score);
        }

        // Sort suggested users based on their scores
        List<User> suggestedUsers = new ArrayList<>(scoreMap.keySet());
        suggestedUsers.sort((u1, u2) -> scoreMap.get(u2) - scoreMap.get(u1));

        // Display suggested friends in the GUI
        if (gui != null) {
            gui.appendToFeed("\n=== Suggested Friends ===");
            for (User suggested : suggestedUsers) {
                gui.appendToFeed(suggested.getUsername() + " (ID: " + suggested.getUserID() + ") - Score: " + scoreMap.get(suggested));
                currentUser.getSuggestionHistory().put(suggested.getUserID(),
                        currentUser.getSuggestionHistory().getOrDefault(suggested.getUserID(), 0) + 1);
            }
        }

        saveUsers();
    }

    // TASK 5 - POSTS

    public void createPost(User user, String content) {
        user.addPost(content);
        saveUsers();
        if (gui != null) {
            gui.appendToFeed("Post created successfully!");
        }
    }

    public void viewFeed() {
        if (gui != null) {
            gui.appendToFeed("\n=== Feed ===");
            for (User user : users.values()) {
                Queue<String> posts = user.getPosts();
                if (!posts.isEmpty()) {
                    gui.appendToFeed("\nPosts by " + user.getUsername() + ":");
                    for (String post : posts) {
                        gui.appendToFeed("- " + post);
                    }
                }
            }
            gui.appendToFeed("\n=== End of Feed ===");
        }
    }



    // OTHER FUNCTIONS

    public void registerUser(String username, String email, String fullName, String location, List<String> interests, String password, String dob) {
        User newUser = new User(username, email, fullName, location, interests, password, dob);
        users.put(newUser.getUserID(), newUser);
        saveUsers();

        if (gui != null) {
            gui.appendToFeed("Registration successful! Your user ID is: " + newUser.getUserID());
        }
    }

    public User loginUser(String username, String password) {
        for (User user : users.values()) {
            if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
                if (gui != null) {
                    gui.appendToFeed("Login successful! Welcome, " + user.getFullName());
                }
                return user;
            }
        }
        if (gui != null) {
            gui.appendToFeed("Invalid username or password.");
        }
        return null;
    }

    private boolean isFriendOfFriend(User currentUser, User potentialFriend) {
        for (UUID friendID : currentUser.getFriends()) {
            User friend = users.get(friendID);
            if (friend != null && friend.getFriends().contains(potentialFriend.getUserID())) {
                return true;
            }
        }
        return false;
    }

    public User getUserByUsername(String username) {
        for (User user : users.values()) {
            if (user.getUsername().equals(username)) {
                return user;
            }
        }
        return null;
    }


    // FILE HANDLING

    void saveUsers() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("users.dat"))) {
            oos.writeObject(users);
        } catch (IOException e) {
            if (gui != null) {
                gui.appendToFeed("Error saving users.");
            }
        }
    }

    private void loadUsers() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream("users.dat"))) {
            users = (Map<UUID, User>) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            users = new HashMap<>();
        }
    }
}