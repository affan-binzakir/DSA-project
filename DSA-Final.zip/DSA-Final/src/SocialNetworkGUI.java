import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.border.*;
import java.util.*;
import java.util.List;

public class SocialNetworkGUI extends JFrame {
    private SocialNetwork socialNetwork;
    private User currentUser;
    private CardLayout cardLayout;
    private JPanel mainPanel;

    // Panels
    private JPanel loginPanel;
    private JPanel registerPanel;
    private JPanel homePanel;

    // Login components
    private JTextField loginUsernameField;
    private JPasswordField loginPasswordField;

    // Register components
    private JTextField regUsernameField;
    private JTextField regEmailField;
    private JTextField regFullNameField;
    private JTextField regLocationField;
    private JTextField regInterestsField;
    private JPasswordField regPasswordField;
    private JTextField regDobField;

    // Home components
    private JTextArea postTextArea;
    private JTextArea feedTextArea;
    private JLabel userProfileLabel;

    public SocialNetworkGUI() {
        socialNetwork = new SocialNetwork();
        socialNetwork.setGUI(this);
        setupFrame();
        createPanels();
        showLoginPanel();
    }

    private void setupFrame() {
        setTitle("Linkify");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1024, 768);
        setLocationRelativeTo(null);
        setMinimumSize(new Dimension(800, 600));

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);
        add(mainPanel);
    }

    private void createPanels() {
        createLoginPanel();
        createRegisterPanel();
        createHomePanel();

        mainPanel.add(loginPanel, "login");
        mainPanel.add(registerPanel, "register");
        mainPanel.add(homePanel, "home");
    }

    private void createLoginPanel() {
        loginPanel = new JPanel(new GridBagLayout());
        loginPanel.setBackground(new Color(240, 242, 245));

        JPanel loginCard = new JPanel();
        loginCard.setLayout(new BoxLayout(loginCard, BoxLayout.Y_AXIS));
        loginCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                BorderFactory.createEmptyBorder(20, 40, 20, 40)
        ));
        loginCard.setBackground(Color.WHITE);
        loginCard.setMaximumSize(new Dimension(400, 500));

        JLabel titleLabel = new JLabel("Linkify");
        titleLabel.setFont(new Font("Serif", Font.BOLD, 34));
        titleLabel.setForeground(new Color(0, 170, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        loginUsernameField = createStyledTextField("Username");
        loginPasswordField = createStyledPasswordField("Password");

        formPanel.add(new JLabel("Username"), gbc);
        gbc.gridy = 1;
        formPanel.add(loginUsernameField, gbc);
        gbc.gridy = 2;
        formPanel.add(new JLabel("Password"), gbc);
        gbc.gridy = 3;
        formPanel.add(loginPasswordField, gbc);

        JButton loginButton = createStyledButton("Login");
        JButton registerButton = createStyledButton("Create Account");

        loginButton.addActionListener(e -> handleLogin());
        registerButton.addActionListener(e -> showRegisterPanel());

        loginCard.add(titleLabel);
        loginCard.add(Box.createRigidArea(new Dimension(0, 20)));
        loginCard.add(formPanel);
        loginCard.add(Box.createRigidArea(new Dimension(0, 20)));
        loginCard.add(loginButton);
        loginCard.add(Box.createRigidArea(new Dimension(0, 10)));
        loginCard.add(registerButton);

        loginPanel.add(loginCard);
    }

    private void createRegisterPanel() {
        registerPanel = new JPanel(new GridBagLayout());
        registerPanel.setBackground(new Color(240, 242, 245));

        JPanel registerCard = new JPanel();
        registerCard.setLayout(new BoxLayout(registerCard, BoxLayout.Y_AXIS));
        registerCard.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                BorderFactory.createEmptyBorder(20, 40, 20, 40)
        ));
        registerCard.setBackground(Color.WHITE);
        registerCard.setMaximumSize(new Dimension(500, 700));

        JLabel titleLabel = new JLabel("Create Account");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(0, 170, 100));
        titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel formPanel = new JPanel(new GridBagLayout());
        formPanel.setBackground(Color.WHITE);
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 0, 5, 0);

        regUsernameField = createStyledTextField("Username");
        regEmailField = createStyledTextField("Email");
        regFullNameField = createStyledTextField("Full Name");
        regLocationField = createStyledTextField("Location");
        regInterestsField = createStyledTextField("Interests (comma-separated)");
        regPasswordField = createStyledPasswordField("Password");
        regDobField = createStyledTextField("Date of Birth (DD/MM/YYYY)");

        addFormField(formPanel, "Username", regUsernameField, gbc, 0);
        addFormField(formPanel, "Email", regEmailField, gbc, 2);
        addFormField(formPanel, "Full Name", regFullNameField, gbc, 4);
        addFormField(formPanel, "Location", regLocationField, gbc, 6);
        addFormField(formPanel, "Interests (comma-separated)", regInterestsField, gbc, 8);
        addFormField(formPanel, "Password", regPasswordField, gbc, 10);
        addFormField(formPanel, "Date of Birth (dd/mm/yyyy)", regDobField, gbc, 12);

        JButton createAccountButton = createStyledButton("Create Account");
        JButton backButton = createStyledButton("Back to Login");

        createAccountButton.addActionListener(e -> handleRegistration());
        backButton.addActionListener(e -> showLoginPanel());

        registerCard.add(titleLabel);
        registerCard.add(Box.createRigidArea(new Dimension(0, 20)));
        registerCard.add(formPanel);
        registerCard.add(Box.createRigidArea(new Dimension(0, 20)));
        registerCard.add(createAccountButton);
        registerCard.add(Box.createRigidArea(new Dimension(0, 10)));
        registerCard.add(backButton);

        registerPanel.add(registerCard);
    }

    private void createHomePanel() {
        homePanel = new JPanel(new BorderLayout(10, 10));
        homePanel.setBackground(new Color(240, 242, 245));
        homePanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create sidebar
        JPanel sidebar = createSidebar();

        // Create main content area
        JPanel contentArea = createContentArea();

        homePanel.add(sidebar, BorderLayout.WEST);
        homePanel.add(contentArea, BorderLayout.CENTER);
    }

    private JPanel createSidebar() {
        JPanel sidebar = new JPanel();
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setBackground(Color.WHITE);
        sidebar.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        sidebar.setPreferredSize(new Dimension(250, 0));

        userProfileLabel = new JLabel();
        userProfileLabel.setFont(new Font("Arial", Font.BOLD, 16));
        userProfileLabel.setAlignmentX(Component.LEFT_ALIGNMENT);

        JButton viewFeedButton = createSidebarButton("View Feed", e -> refreshFeed());
        JButton viewFriendRequestsButton = createSidebarButton("Friend Requests", e -> handleViewFriendRequests());
        JButton viewFriends = createSidebarButton("My Friends", e -> handleViewFriends());
        JButton removeFriendButton = createSidebarButton("Remove Friend", e -> handleRemoveFriend());
        JButton sendRequestButton = createSidebarButton("Send Friend Request", e -> handleSendFriendRequest());
        JButton mutualFriendsButton = createSidebarButton("View Mutual Friends", e -> handleViewMutualFriends());
        JButton suggestFriendsButton = createSidebarButton("Friend Suggestions", e -> handleFriendSuggestions());
        JButton logoutButton = createSidebarButton("Logout", e -> handleLogout());


        sidebar.add(userProfileLabel);
        sidebar.add(Box.createRigidArea(new Dimension(0, 20)));
        sidebar.add(viewFeedButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(viewFriendRequestsButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(viewFriends);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(sendRequestButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(removeFriendButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(mutualFriendsButton);
        sidebar.add(Box.createRigidArea(new Dimension(0, 5)));
        sidebar.add(suggestFriendsButton);
        sidebar.add(Box.createVerticalGlue());
        sidebar.add(logoutButton);

        return sidebar;
    }

    private JPanel createContentArea() {
        JPanel contentArea = new JPanel(new BorderLayout(0, 10));
        contentArea.setBackground(Color.WHITE);
        contentArea.setBorder(new EmptyBorder(15, 15, 15, 15));

        // Create post area
        JPanel postPanel = new JPanel(new BorderLayout(0, 10));
        postPanel.setBackground(Color.WHITE);
        postPanel.setBorder(new CompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                new EmptyBorder(15, 15, 15, 15)
        ));

        JLabel postLabel = new JLabel("Create Post");
        postLabel.setFont(new Font("Arial", Font.BOLD, 16));

        postTextArea = new JTextArea(4, 30);
        postTextArea.setLineWrap(true);
        postTextArea.setWrapStyleWord(true);
        JScrollPane postScroll = new JScrollPane(postTextArea);

        JButton postButton = createStyledButton("Post");
        postButton.addActionListener(e -> handleCreatePost());

        postPanel.add(postLabel, BorderLayout.NORTH);
        postPanel.add(postScroll, BorderLayout.CENTER);
        postPanel.add(postButton, BorderLayout.SOUTH);

        // Create feed area
        feedTextArea = new JTextArea();
        feedTextArea.setEditable(false);
        feedTextArea.setLineWrap(true);
        feedTextArea.setWrapStyleWord(true);
        JScrollPane feedScroll = new JScrollPane(feedTextArea);
        feedScroll.setBorder(new LineBorder(new Color(220, 225, 230), 1));

        contentArea.add(postPanel, BorderLayout.NORTH);
        contentArea.add(feedScroll, BorderLayout.CENTER);

        return contentArea;
    }

    private JButton createSidebarButton(String text, ActionListener listener) {
        JButton button = new JButton(text);
        button.setMaximumSize(new Dimension(220, 40));
        button.setAlignmentX(Component.LEFT_ALIGNMENT);
        button.setBorderPainted(false);
        button.setContentAreaFilled(false);
        button.setFocusPainted(false);
        button.setHorizontalAlignment(SwingConstants.LEFT);
        button.setFont(new Font("Arial", Font.PLAIN, 14));
        button.addActionListener(listener);

        button.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) {
                button.setBackground(new Color(240, 242, 245));
                button.setContentAreaFilled(true);
            }
            public void mouseExited(MouseEvent e) {
                button.setContentAreaFilled(false);
            }
        });

        return button;
    }

    private JTextField createStyledTextField(String placeholder) {
        JTextField field = new JTextField(20);
        field.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JPasswordField createStyledPasswordField(String placeholder) {
        JPasswordField field = new JPasswordField(20);
        field.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(new Color(220, 225, 230), 1),
                BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        return field;
    }

    private JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setMaximumSize(new Dimension(200, 40));
        button.setBackground(new Color(0, 170, 100));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorderPainted(false);
        button.setOpaque(true);
        return button;
    }

    private void addFormField(JPanel panel, String label, JComponent field, GridBagConstraints gbc, int gridy) {
        gbc.gridy = gridy;
        panel.add(new JLabel(label), gbc);
        gbc.gridy = gridy + 1;
        panel.add(field, gbc);
    }

    private void handleLogin() {
        String username = loginUsernameField.getText();
        String password = new String(loginPasswordField.getPassword());

        currentUser = socialNetwork.loginUser(username, password);
        if (currentUser != null) {
            showHomePanel();
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username or password", "Login Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void handleRegistration() {
        String username = regUsernameField.getText();
        String email = regEmailField.getText();
        String fullName = regFullNameField.getText();
        String location = regLocationField.getText();
        List<String> interests = Arrays.asList(regInterestsField.getText().split(","));
        String password = new String(regPasswordField.getPassword());
        String dob = regDobField.getText();

        // Ensure required fields are not empty
        if (username.isEmpty() || email.isEmpty() || fullName.isEmpty() || password.isEmpty() || dob.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check email format
        if (!User.isValidEmail(email)) {
            JOptionPane.showMessageDialog(this, "Invalid email format. Please enter a valid email.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check DOB format
        if (!User.isValidDOB(dob)) {
            JOptionPane.showMessageDialog(this, "Invalid date of birth format. Use dd/mm/yyyy.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Check age restriction
        if (!User.isAgeAllowed(dob)) {
            JOptionPane.showMessageDialog(this, "You must be 13 years or older to register.", "Registration Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        // Proceed with registration
        socialNetwork.registerUser(username, email, fullName, location, interests, password, dob);
        JOptionPane.showMessageDialog(this, "Registration successful! Please login.", "Success", JOptionPane.INFORMATION_MESSAGE);
        showLoginPanel();

        // Clear fields
        regUsernameField.setText("");
        regEmailField.setText("");
        regFullNameField.setText("");
        regLocationField.setText("");
        regInterestsField.setText("");
        regPasswordField.setText("");
        regDobField.setText("");
    }


    private void handleCreatePost() {
        String content = postTextArea.getText().trim();
        if (!content.isEmpty()) {
            socialNetwork.createPost(currentUser, content);
            postTextArea.setText("");
            refreshFeed();
        } else {
            JOptionPane.showMessageDialog(this,
                    "Please enter some content for your post",
                    "Empty Post",
                    JOptionPane.WARNING_MESSAGE);
        }
    }

    private void handleSendFriendRequest() {
        String username = JOptionPane.showInputDialog(this,
                "Enter username to send friend request:",
                "Send Friend Request",
                JOptionPane.PLAIN_MESSAGE);

        if (username != null && !username.trim().isEmpty()) {
            socialNetwork.sendFriendRequest(currentUser, username.trim());
        }
    }

    private void handleViewFriendRequests() {
        socialNetwork.showFriendRequests(currentUser);

        if (!currentUser.getFriendRequests().isEmpty()) {
            String username = JOptionPane.showInputDialog(this,
                    "Enter username to accept friend request:",
                    "Accept Friend Request",
                    JOptionPane.PLAIN_MESSAGE);

            if (username != null && !username.trim().isEmpty()) {
                socialNetwork.acceptFriendRequest(currentUser, username.trim());
            }
        }
    }

    private void handleViewFriends() {
        socialNetwork.viewFriends(currentUser);
    }

    private void handleRemoveFriend() {
        String friendUsername = JOptionPane.showInputDialog(this,
                "Enter username to remove friend:",
                "Remove Friend",
                JOptionPane.PLAIN_MESSAGE);

        if (friendUsername != null && !friendUsername.trim().isEmpty()) {
            socialNetwork.removeFriend(currentUser, friendUsername.trim());
        }
    }



    private void handleViewMutualFriends() {
        String username = JOptionPane.showInputDialog(this,
                "Enter username to view mutual friends:",
                "View Mutual Friends",
                JOptionPane.PLAIN_MESSAGE);

        if (username != null && !username.trim().isEmpty()) {
            socialNetwork.showMutualFriends(currentUser, username.trim());
        }
    }

    private void handleFriendSuggestions() {
        // First clear any existing suggestions
        feedTextArea.setText("");
        // Then call the social network method
        socialNetwork.suggestFriends(currentUser);
    }

    private void handleLogout() {
        currentUser = null;
        loginUsernameField.setText("");
        loginPasswordField.setText("");
        showLoginPanel();
    }

    private void showLoginPanel() {
        cardLayout.show(mainPanel, "login");
    }

    private void showRegisterPanel() {
        cardLayout.show(mainPanel, "register");
    }

    private void showHomePanel() {
        cardLayout.show(mainPanel, "home");
        if (currentUser != null) {
            userProfileLabel.setText("Welcome, " + currentUser.getFullName());
            refreshFeed();
        }
    }

    private void refreshFeed() {
        feedTextArea.setText("");  // Clear the current feed
        socialNetwork.viewFeed();  // This will trigger appendToFeed with the feed content
    }

    public void appendToFeed(String message) {
        SwingUtilities.invokeLater(() -> {
            if (message.startsWith("=== Feed ===")) {
                feedTextArea.setText(""); // Clear existing feed
                updateFeedContent(message);
            }
            else if (message.startsWith("=== Suggested Friends ===")) {
                showSuggestedFriendsDialog(message);
            }
            // Keep the rest of your existing appendToFeed conditions...
            else if (!message.startsWith("===")) {
                // For regular feed content
                feedTextArea.append(message + "\n");
            }
        });
    }
    private void updateFeedContent(String message) {
        // Since feed comes through appendToFeed, append to existing content
        feedTextArea.append(message + "\n");
    }

    private void showFriendRequestsDialog(String message) {
        String[] lines = message.split("\n");
        if (lines.length > 1) {
            StringBuilder requests = new StringBuilder("Pending Friend Requests:\n\n");
            for (int i = 1; i < lines.length; i++) {
                if (lines[i].startsWith("- ")) {
                    requests.append(lines[i].substring(2)).append("\n");
                }
            }

            JTextArea textArea = new JTextArea(requests.toString());
            textArea.setEditable(false);
            textArea.setBackground(null);
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(300, 200));

            JOptionPane.showMessageDialog(this,
                    scrollPane,
                    "Friend Requests",
                    JOptionPane.PLAIN_MESSAGE);
        }
    }

    private void showMutualFriendsDialog(String message) {
        String[] lines = message.split("\n");
        StringBuilder mutuals = new StringBuilder();
        boolean hasMutuals = false;

        // Skip the first line (header) and process the rest
        for (int i = 1; i < lines.length; i++) {
            String line = lines[i].trim();
            if (!line.isEmpty()) {
                mutuals.append(line).append("\n");
                hasMutuals = true;
            }
        }

        if (hasMutuals) {
            JTextArea textArea = new JTextArea(mutuals.toString());
            textArea.setEditable(false);
            textArea.setBackground(null);
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(300, 200));

            JOptionPane.showMessageDialog(this,
                    scrollPane,
                    "Mutual Friends",
                    JOptionPane.PLAIN_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this,
                    "No mutual friends found.",
                    "Mutual Friends",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void showSuggestedFriendsDialog(String message) {
        String[] lines = message.split("\n");
        StringBuilder suggestions = new StringBuilder();
        boolean hasSuggestions = false;

        for (String line : lines) {
            // Skip the header and footer lines
            if (!line.startsWith("===")) {
                suggestions.append(line).append("\n");
                hasSuggestions = true;
            }
        }

        if (hasSuggestions) {
            // Create a more visible dialog for suggestions
            JDialog dialog = new JDialog(this, "Friend Suggestions", true);
            dialog.setLayout(new BorderLayout());

            JTextArea textArea = new JTextArea(suggestions.toString());
            textArea.setEditable(false);
            textArea.setBackground(Color.WHITE);
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);

            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(400, 300));

            dialog.add(scrollPane, BorderLayout.CENTER);

            JButton closeButton = new JButton("Close");
            closeButton.addActionListener(e -> dialog.dispose());

            JPanel buttonPanel = new JPanel();
            buttonPanel.add(closeButton);
            dialog.add(buttonPanel, BorderLayout.SOUTH);

            dialog.pack();
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        } else {
            JOptionPane.showMessageDialog(this,
                    "No friend suggestions available at this time.",
                    "Friend Suggestions",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    public static void main(String[] args) {
        try {
            // Set system look and feel
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());

            // Update all components to use system look and feel
            SwingUtilities.updateComponentTreeUI(new JFrame());
        } catch (Exception e) {
            e.printStackTrace();
        }

        SwingUtilities.invokeLater(() -> {
            SocialNetworkGUI gui = new SocialNetworkGUI();
            gui.setVisible(true);
        });
    }
}